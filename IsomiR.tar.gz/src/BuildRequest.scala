

/**
 * @author danglot
 */
object BuildRequest extends App {

  val k = 3

  for (x <- 1 to k + 1) {
    for (i <- x + 1 to k + 2) {
      val j = (i - x - 1)
      val e = x - 1
      if (e + j == k)
        if (x == i - 1)
          println(e + "[ C_" + x + "^*" + " ; C_" + i + "^*]")
        else
          println(e + "[ C_" + x + " ; C_" + i + "^*]")
      else
        println(e + "[ C_" + x + " ; C_" + i + "^" + j + "]")
    }
  }

}
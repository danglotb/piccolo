

/**
 * @author danglot
 */
object BuildTest extends App {

  def randomNt(): Char = {
    val index = (new java.util.Random().nextInt(4))
    index match {
      case 0 => 'A'
      case 1 => 'C'
      case 2 => 'G'
      case _ => 'U'
    }
  }

  def deletion(s: String, index: List[Int]): String = {
    val ret = (s.toBuffer)
    index.foreach { x => ret remove (x) }
    ret.mkString
  }

  def insertion(s: String, index: List[Int]): String = {
    val ret = (s.toBuffer)
    index.foreach { x => ret insert (x, randomNt) }
    ret.mkString
  }

  def mismatch(s: String, index: List[Int]): String = {
    var ret = (s.toBuffer)
    index.foreach { x =>
      var nt = randomNt
      while (nt == ret(x))
        nt = randomNt
      ret = ret updated (x, nt)

    }
    ret.mkString
  }

  def mix(s: String, index: List[Int]): String = {
    var ret = s
    index.foreach { i =>
      val r = (new java.util.Random()).nextInt(3)
      r match {
        case 0 => ret = mismatch(ret, List(i))
        case 1 => ret = insertion(ret, List(i))
        case 2 => ret = deletion(ret, List(i))
      }
    }
    ret
  }

  def max3(a: Int, b: Int, c: Int): Int = Math.max(a, Math.max(b, c))
  def min3(a: Int, b: Int, c: Int): Int = Math.min(a, Math.min(b, c))

  def buildIndices3(indices2: List[(Int, Int)], z: List[Int]): List[(Int, Int, Int)] = {
    val list = new scala.collection.mutable.ListBuffer[(Int, Int, Int)]()
    indices2.foreach { c =>
      z.diff(List(c._1, c._2)).foreach { i =>
        val max = max3(c._1, c._2, i)
        val min = min3(c._1, c._2, i)
        val other = if (c._1 == max) if (c._2 == min) i else c._2 else if (c._1 == min) if (c._2 == max) i else c._2 else c._1
        list += ((max, other, min))
      }
    }
    list.toList
  }

  val ref = "GCUCACUGCUCUUUCUGUCAGA"

  val indices = ref.indices

  val tails = indices.tail map (i => indices drop i)

  val indices3 = ref.indices

  val indices2 = scala.util.Random.shuffle((indices zip tails) flatMap (c => c._2 map (i => (Math.max(c._1, i), Math.min(c._1, i)))))

  println(indices2)

  val index = buildIndices3(indices2.toList, indices3.toList)

  println(index)
  
//  val mix3 = index.map { x => mix(ref, List(x._1, x._2, x._3)) }
//
//  val del3 = index.map { x => deletion(ref, List(x._1, x._2, x._3)) }
//
//  val ins3 = index.map { x => insertion(ref, List(x._1, x._2, x._3)) }

  val mm3 = index.map { x => mismatch(ref, List(x._1, x._2, x._3)) }
  
  var str = ""

  mm3.foreach { d =>
    str += ">mm3\n" + d + "\n"
  }

  Some(new java.io.PrintWriter("mm3")).foreach { p => p.write(str); p.close }
//
//  str = ""
//
//  ins3.foreach { d =>
//    str += ">ins3\n" + d + "\n"
//  }
//
//  Some(new java.io.PrintWriter("ins3")).foreach { p => p.write(str); p.close }
//
//  str = ""
//
//  del3.foreach { d =>
//    str += ">del3\n" + d + "\n"
//  }
//
//  Some(new java.io.PrintWriter("del3")).foreach { p => p.write(str); p.close }

}


/**
 * @author danglot
 */
object FilterDB extends App {

  def readMirbase(it: Iterator[String],
                  printer: java.io.PrintWriter = new java.io.PrintWriter("MirbaseFile.fa")): Unit = {
    if (!(it hasNext)) {
      printer.close()
      return
    } else {

      val head = it next ()
      val seq = it next ()

      if (seq.length() >= 16 && seq.length <= 25) {

        printer.write(head + "\n")
        printer.write(seq + "\n")

      }

      readMirbase(it, printer)
    }
  }

  def readInput(it: Iterator[String],
                printer: java.io.PrintWriter = new java.io.PrintWriter("GSM518430-13540.fa")): Unit = {
    if (!(it hasNext)) {
      printer.close()
      return
    } else {

      val line = it next ()
      val sc = new java.util.Scanner(line)
      sc useDelimiter ("\t")

      val seq = sc next ()
      val count = sc next ()

      if (seq.length() >= 16 && seq.length <= 25) {

        val head = ">" + seq + " | " + count

        printer.write(head + "\n")
        printer.write(seq + "\n")

      }

      readInput(it, printer)
    }
  }

  val source = scala.io.Source.fromFile("GSM518430-13540.txt").getLines

  source next ()
  source next ()
  source next ()

  readInput(source)

  val source2 = scala.io.Source.fromFile("MirbaseFile.txt").getLines
  
  readMirbase(source2)
}
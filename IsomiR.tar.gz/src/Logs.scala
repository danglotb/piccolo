

/**
 * @author danglot
 */

object Logs extends App {

  var avg_time = 0.0
  var avg_memory = 0
  
  for (i <- 1 to 10) {

    val source = scala.io.Source.fromFile("noOption/time_" + i).getLines

    source next ()

    val time = source next ()
    
    var sc = new java.util.Scanner(time)
    sc useDelimiter(":")
    sc next()
    
    avg_time += (sc next()).toDouble

    for (i <- 0 until 7) source next ()

    val memory = source next ()
    sc = new java.util.Scanner(memory)
    sc useDelimiter(": ")
    sc next()
    
    avg_memory += (sc next()).toInt
  }
  
  println("avg_time : "+ (avg_time / 10))
  println("avg_memory :"+ (avg_memory / 10))

}
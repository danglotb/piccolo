

/**
 * @author danglot
 */
object Main extends App {

  def cutFile(it: Iterator[String]): Unit = {
    var cpt = 0
    while (source hasNext) {
      Some(new java.io.PrintWriter("out/test_" + cpt)).foreach { p => p.write(read4k(it)); p.close }
      cpt += 1;
    }
  }

  def read4k(it: Iterator[String], str: String = "", nb: Int = 0): String = {
    if (!(it.hasNext) || nb == 4000)
      str
    else {
      val head = it.next()
      val line = it.next()
      read4k(it, str + (head + "\n" + line + "\n"), nb + 1)
    }
  }

  val source = scala.io.Source.fromFile("GSM518430-13540.txt")
  val lines = source.getLines

  //trash header
  lines next()
  lines next()
  lines next()
  
  val printer = new java.io.PrintWriter("GSM518430-13540.txt")
  
  while(lines hasNext) {
    
    val line = lines next()
    val sc = new java.util.Scanner(line)
    sc useDelimiter("\t")
    
    val seq = sc next()
    
    if (seq.length > 19 && seq.length < 25) {
      val count = sc.next()
    
      printer.write("> " + seq + " | " + count + "\n")
      printer.write(seq + "\n")
  
    }
  
    sc close()
  
  }
  
  printer.close()
  source.close()
}


/**
 * @author danglot
 */

object filter extends App {
  val printer: java.io.PrintWriter = new java.io.PrintWriter("RndBase.fa")
  var cpt = 0
  val list = List("250000_seqs_19_19_bp.fasta", "250000_seqs_20_20_bp.fasta", "250000_seqs_21_21_bp.fasta", "250000_seqs_22_22_bp.fasta")

  list.foreach { path =>
    if (cpt % 5000 == 0) println(cpt)
    val source = scala.io.Source.fromFile(path)
    val mirBase = source.getLines
    while (mirBase hasNext) {
      val line = mirBase next ()
      if (line.size > 0) {
        if (line.startsWith(">")) {
          printer.println(line + "\t" + cpt)
          cpt += 1
        } else
          printer.println(line)
      }
    }
    source close ()
  }
  printer.close()
}

object removeSpace extends App {

  val list = List("250000_seqs_19_19_bp.fasta", "250000_seqs_20_20_bp.fasta", "250000_seqs_21_21_bp.fasta", "250000_seqs_22_22_bp.fasta")

  var cpt = 0

  list.foreach { path =>
    val source = scala.io.Source.fromFile(path)
    val lines = source.getLines

    val printer = new java.io.PrintWriter(path.substring(7))

    while (lines hasNext) {
      val line = lines next ()
      if (line.size > 0)
        if (line.startsWith(">")) {
          printer.println(line + "\t" + cpt)
          cpt += 1
        } else
          printer.println(line)
    }
    source.close()
    printer.close()
  }
}

object RndGen extends App {

  val sourceMirBase = scala.io.Source.fromFile("MirbaseFile.fa")
  val linesMirBase = sourceMirBase getLines

  val sourceRnd = scala.io.Source.fromFile("RndBase.fa")
  val linesRnd = sourceRnd getLines

  val printer = new java.io.PrintWriter("mixAlea")

  def waste(rnd: Iterator[String], nb: Int = 500): Iterator[String] = {
    for (i <- 0 until (new java.util.Random()).nextInt(nb)*2) 
      rnd.next()
    return rnd
  }

  def add(it: Iterator[String], printer: java.io.PrintWriter, bound : Int = 10, cpt: Int = 0): Unit = {
    if (cpt <= bound) {
      printer.println(it.next())
      printer.println(it.next())
      add(it, printer, bound, cpt + 1)
    }
  }

  def mirbase(base: Iterator[String], rnd: Iterator[String], printer: java.io.PrintWriter, bound: Int = 15, cpt: Int = 0): Unit = {
    if (cpt <= bound) {
      add(base, printer, 0, 0)
      add(waste(rnd), printer)
      mirbase(base, rnd, printer, bound, cpt + 1)
    }
  }

  val list = List("seqs_19_19_bp.fasta", "seqs_20_20_bp.fasta", "seqs_21_21_bp.fasta", "seqs_22_22_bp.fasta")

  list.foreach { path =>
    val current = scala.io.Source.fromFile(path).getLines
    mirbase(linesMirBase, waste(current), printer)
  }
}